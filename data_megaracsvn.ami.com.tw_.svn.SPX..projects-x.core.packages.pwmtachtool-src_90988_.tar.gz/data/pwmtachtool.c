/*
 ****************************************************************
 **                                                            **
 **    (C)Copyright 2009-2015, American Megatrends Inc.        **
 **                                                            **
 **            All Rights Reserved.                            **
 **                                                            **
 **        5555 Oakbrook Pkwy Suite 200, Norcross,             **
 **                                                            **
 **        Georgia - 30093, USA. Phone-(770)-246-8600.         **
 **                                                            **
 ****************************************************************
 */

/*
 * PwmTach Tool Application
 *
 * Copyright (C) 2009-2015 American Megatrends Inc.
 *
 * This application provides functions to get configure the fan pwm-tach mappings and properties and get/set the status/speed of the fans.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <stdint.h>
#include <limits.h>
#include "libpwmtach.h"
#include "fan_structs.h"

#define VERSION_STR "1.1"
typedef enum {
	ENABLE_FAN_CONTROL,
	ENABLE_ALL_FANS_CONTROL,
	GET_FAN_CONTROL_STATUS,
	ENABLE_FAN_STATUS_READ,
	ENABLE_ALL_FANS_STATUS_READ,
	GET_FAN_STATUS_READ,
	SET_FAN_SPEED,
	GET_FAN_SPEED,
	DISABLE_FAN_CONTROL,
	DISABLE_ALL_FANS_CONTROL,
	DISABLE_FAN_STATUS_READ,
	DISABLE_ALL_FANS_STATUS_READ,
	CONF_FAN_MAP_TABLE,
	CONF_FAN_PROPERTY_TABLE,
	SHOW_FAN_MAP_TABLE,
	SHOW_FAN_PROPERTY_TABLE,
	SET_PWM_DUTYCYCLE,
	SET_PWM_DUTYCYCLE_VALUE,
	GET_PWM_DUTYCYCLE,
	SET_TACH_PROPERTY,
	GET_TACH_PROPERTY,
	SET_PWM_PROPERTY,
	GET_PWM_PROPERTY,
	CLEAR_TACH_ERROR,
	CLEAR_PWM_ERRORS,
	END_OF_FUNCLIST
}ePwmTachactions;


ePwmTachactions action = END_OF_FUNCLIST;

static int verbose = 0;

static void ShowUsage ( void )
	/*@globals fileSystem@*/
	/*@modifies fileSystem@*/
{
	printf ("PWMTACH Test Tool (Version %s)\n",VERSION_STR);
	printf ("Copyright (c) 2009-2015 American Megatrends Inc.\n");	
	printf( "Usage : pwmtachtool <device_id> <command-option> <fannum>\n" );
	printf( "\t--enable-fan:            Enable Fan Control\n" );
	printf( "\t--enable-all-fans:       Enable Control for all the Fans\n" );
	printf( "\t--get-fan-status:         Get Enable Status of Fan Control\n" );
	printf( "\t--enable-fan-read:       Enable Fan Status Read\n" );
	printf( "\t--enable-all-fans-read:  Enable Status Read for all Fans\n" );
	printf( "\t--get-fan-read-status:         Get Enable Status Read of Fan Control\n" );
	printf( "\t--set-fan-speed:         Set Fan's speed. Takes the RPM value as the last argument\n" );
		printf("\t\tparameters: <Fan_Number> <Fan_Speed>\n");
	printf( "\t--set-pwm-dutycycle:         Set Fan's dutycycle. dutycycle_percentage value should be between 1 to 100\n" );
		printf("\t\tparameters: <pwm_number> <dutycycle>\n");
	printf( "\t--set-pwm-dutycycle-value:   Set Fan's dutycycle. dutycycle_value should be between 0 to 255\n" );
		printf("\t\tparameters: <pwm_number> <dutycycle value>\n");
	printf( "\t--get-pwm-dutycycle:		Get Fan's dutycycle\n");
	printf( "\t--get-fan-speed:         Get Fan's speed\n" );
	printf( "\t--disable-fan:           Disable Fan Control\n" );
	printf( "\t--disable-all-fans:      Disable Control for all the Fans\n" );
	printf( "\t--disable-fan-read:      Disable Fan Status Read\n" );
	printf( "\t--disable-all-fans-read: Disable Status Read for all Fans\n" );
	printf( "\t--configure-fan-map-table: Configure Fan Map Table for Fan-PWM and Fan-Tach mappings\n");
		printf("\t\tparameters: <TOTAL_FAN_NUM_N> <FAN_1> <PWM_1> <TACH_1> ... <FAN_N> <PWM_N> <TACH_N>\n");
	printf( "\t--configure-fan-property-table: Configure Fan Properties for given Fan number\n");
		printf("\t\tparameters: <TOTAL_FAN_NUM_N> <FAN_NUM_0> <MIN_RPM_0> <MAX_RPM_0> <PULSES_PER_REVOLUTION_0> ... <FAN_NUM_N> <MIN_RPM_N> <MAX_RPM_N> <PULSES_PER_REVOLUTION_N>\n");
	printf( "\t--show-fan-map-table: 	Show Fan Map Table\n");
	printf( "\t--show-fan-property-table: 	Show Fan Properties for given Fan Number\n");
	printf( "\t--set-tach-property:     Set Tach property\n");
		printf( "\t\tparameters: <Tach_number> <Property> <value>\n");
	printf( "\t--get-tach-property:     Get Tach property value\n");
		printf( "\t\tparameters: <Tach_number> <Property>\n");
	printf( "\t--set-pwm-property:     Set PWM property\n");
		printf( "\t\tparameters: <PWM_number> <Property> <value>\n");
	printf( "\t--get-pwm-property:     Get PWM property value\n");
		printf( "\t\tparameters: <Tach_number> <Property>\n");
	printf( "\t--clear-tach-error:     Clear Tach Error\n");
		printf( "\t\tparameters: <Tach_number>\n");
	printf( "\t--clear-pwm-errors:     Clear PWM Errors\n");
	printf( "\t--verbose:              Verbose for Debugging messages \n" );
	printf( "\n" );
}

static void Verbose ( char * msg )
{
	if (verbose ) printf ( "%s\n" , msg );
}

static int process_arguments( int argc, char **argv,
		unsigned char* fan_num,unsigned int* rpm_value, struct fan_map_entry_t** pp_fanmap_data,
		struct fan_property_t** pp_fanproperty_data, unsigned int* p_num_fans, unsigned char* property_id,
		unsigned int* property_value, unsigned int* dev_id )
{
	int i = 1;
	unsigned int j = 0;

	if (argc < 3)
	{
		printf("need Device Name and Command to process request\n");
		return -1;
	}

	*dev_id = (unsigned char)strtol( argv[ i++ ], NULL, 10);

	if( strcmp( argv[ i ], "--enable-fan" ) == 0 )
	{
		action = ENABLE_FAN_CONTROL;
		if (argc < 4)
		{
			printf("need Fan Number to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--enable-all-fans" ) == 0 )
	{
		action = ENABLE_ALL_FANS_CONTROL;
	}
	else if ( strcmp( argv[ i ], "--get-fan-status" ) == 0 )
	{
		action = GET_FAN_CONTROL_STATUS;
		if (argc < 4)
		{
			printf("need Fan Number to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--enable-fan-read" ) == 0 )
	{
		action = ENABLE_FAN_STATUS_READ;
		if (argc < 4)
		{
			printf("need Fan Number to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--enable-all-fans-read" ) == 0 )
	{
		action = ENABLE_ALL_FANS_STATUS_READ;
	}
	else if( strcmp( argv[ i ], "--get-fan-read-status" ) == 0 )
	{
		action = GET_FAN_STATUS_READ;
		if (argc < 4)
		{
			printf("need Fan Number to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--set-fan-speed" ) == 0 )
	{
		if (argc < 5)
		{
			printf("need Fan Number and RPM value to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*rpm_value = (unsigned int)strtol( argv[ ++i ], NULL, 10);
		action = SET_FAN_SPEED;
	}
	else if( strcmp( argv[ i ], "--set-pwm-dutycycle" ) == 0 )
	{
		if (argc < 5)
		{
			printf("need Fan Number and Dutycycle value to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*rpm_value = (unsigned int)strtol( argv[ ++i ], NULL, 10);
		action = SET_PWM_DUTYCYCLE;
	}
	else if( strcmp( argv[ i ], "--set-pwm-dutycycle-value" ) == 0 )
	{
		if (argc < 5)
		{
			printf("need Fan Number and Dutycycle value to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*rpm_value = (unsigned int)strtol( argv[ ++i ], NULL, 10);
		action = SET_PWM_DUTYCYCLE_VALUE;
	}
	else if( strcmp( argv[i], "--get-pwm-dutycycle" ) == 0)
	{
		if (argc < 4)
		{
			printf("need PWM Number to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		action = GET_PWM_DUTYCYCLE;
	}

	else if( strcmp( argv[ i ], "--get-fan-speed" ) == 0 )
	{
		if (argc < 4)
		{
			printf("need more parameters to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		action = GET_FAN_SPEED;
	}
	if( strcmp( argv[ i ], "--disable-fan" ) == 0 )
	{
		action = DISABLE_FAN_CONTROL;
		if (argc < 4)
		{
			printf("need more parameters to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--disable-all-fans" ) == 0 )
	{
		action = DISABLE_ALL_FANS_CONTROL;
	}
	else if( strcmp( argv[ i ], "--disable-fan-read" ) == 0 )
	{
		action = DISABLE_FAN_STATUS_READ;
		if (argc < 4)
		{
			printf("need more parameters to process request\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--disable-all-fans-read" ) == 0 )
	{
		action = DISABLE_ALL_FANS_STATUS_READ;
	}
	else if( strcmp( argv[ i ], "--configure-fan-map-table" ) == 0 )
	{
		action = CONF_FAN_MAP_TABLE;
		if (argc < 4) 
		{
			printf("need NumberOfFans to process request\n");
			return -1;
		}
		*p_num_fans = (unsigned int) strtol(argv[++i],NULL,10);
		if (argc < (long int)(4 + (*p_num_fans)*3))	/*-Wextra, Fix for comparison error*/
		{
			printf("\nfan_map: need MapEntries\n\n");
			return -1;
		}
		if(sizeof(struct fan_map_entry_t) > INT_MAX)
		{
			printf("Error:Integer overflow\n");
			return -1;
		}
		*pp_fanmap_data = (struct fan_map_entry_t*) malloc(sizeof(struct fan_map_entry_t) * (*p_num_fans));
		if(*pp_fanmap_data == NULL)
		{
			printf("Error in allocating memory\n");
			return -1;
		}
		for (j=0; j<(*p_num_fans); j++)	
		{
			(*pp_fanmap_data)[j].fan_num = (unsigned int) strtol(argv[++i], NULL, 10);
			(*pp_fanmap_data)[j].pwm_num = (unsigned int) strtol(argv[++i], NULL, 10);
			(*pp_fanmap_data)[j].tach_num = (unsigned int) strtol(argv[++i], NULL, 10);
		}
		return 0;
	}
	else if( strcmp( argv[ i ], "--configure-fan-property-table" ) == 0 )
	{
		action = CONF_FAN_PROPERTY_TABLE;
		if (argc < 4)
		{
			printf("\nneed NumberOfFans to process request\n");
			return -1;
		}
		*p_num_fans = (unsigned int) strtol(argv[++i],NULL,10);
		if (argc < (long int)(4 + (*p_num_fans)*4))	/*-Wextra, Fix for comparison error*/
		{
			printf("\nfan_property: need FanProperties\n\n");
			return -1;
		}
		if(sizeof(struct fan_property_t) > INT_MAX)
		{
			printf("Error:Integer overflow\n");
			return -1;
		}
		*pp_fanproperty_data = (struct fan_property_t*) malloc(sizeof(struct fan_property_t) * (*p_num_fans));
		if(*pp_fanproperty_data == NULL)
		{
			printf("Error in allocating memory\n");
			return -1;
		}
		for (j=0; j<(*p_num_fans); j++)	
		{
			(*pp_fanproperty_data)[j].fan_num = (unsigned int) strtol(argv[++i],NULL,10);
			(*pp_fanproperty_data)[j].min_rpm = (unsigned int) strtol(argv[++i],NULL,10);
			(*pp_fanproperty_data)[j].max_rpm = (unsigned int) strtol(argv[++i],NULL,10);
			(*pp_fanproperty_data)[j].pulses_per_revolution = (unsigned int) strtol(argv[++i],NULL,10);
		}
		return 0;
	}
	else if( strcmp( argv[ i ], "--show-fan-map-table" ) == 0 )
	{
		action = SHOW_FAN_MAP_TABLE;
	}
	else if( strcmp( argv[ i ], "--show-fan-property-table" ) == 0 )
	{
		action = SHOW_FAN_PROPERTY_TABLE;
	}
	else if( strcmp( argv[ i ], "--set-tach-property" ) == 0 )
	{
		action = SET_TACH_PROPERTY;
		if (argc < 6)
		{
			printf("\nNeed Tach number, Property ID, and Property Value\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*property_id = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*property_value = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--get-tach-property" ) == 0 )
	{
		action = GET_TACH_PROPERTY;
		if (argc < 5)
		{
			printf("\nNeed Tach number, and Property ID\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*property_id = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--set-pwm-property" ) == 0 )
	{
		action = SET_PWM_PROPERTY;
		if (argc < 6)
		{
			printf("\nNeed PWM number, Property ID, and Property Value\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*property_id = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*property_value = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--get-pwm-property" ) == 0 )
	{
		action = GET_PWM_PROPERTY;		
		if (argc < 5)
		{
			printf("\nNeed PWM number, and Property ID\n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);
		*property_id = (unsigned char)strtol( argv[ ++i ], NULL, 10);
	}
	else if( strcmp( argv[ i ], "--clear-tach-error" ) == 0 )
	{
		action = CLEAR_TACH_ERROR;			
		if (argc < 4)
		{
			printf("\nNeed tach number \n");
			return -1;
		}
		*fan_num = (unsigned char)strtol( argv[ ++i ], NULL, 10);			
	}
	else if( strcmp( argv[ i ], "--clear-pwm-errors" ) == 0 )
	{
		action = CLEAR_PWM_ERRORS;						
	}
	else if( strcmp( argv[ i ], "--verbose" ) == 0 )
		verbose = 1;
	return 0;
}

int main ( int argc , char* argv [] )
{
	unsigned char fannum = 0, property_id = 0;
	unsigned int rpmvalue = 0;
	unsigned char dutycycle = 0;
	struct fan_map_entry_t* p_fanmap_data = NULL;
	struct fan_property_t* p_fanproperty_data = NULL;
	int Value = 0;
	int ret = 0;
	unsigned int num_fans = 0;
	unsigned int dev_id = 0, property_value = 0;

	if (argc < 2)
	{
		ShowUsage();
		return 0;
	}
	ret = process_arguments( argc , argv , &fannum, &rpmvalue, &p_fanmap_data, &p_fanproperty_data, &num_fans, &property_id, &property_value, &dev_id );
	if (ret != 0)
       {  
               free(p_fanmap_data);
               p_fanmap_data = NULL;
               free(p_fanproperty_data);
               p_fanproperty_data = NULL;
		return -1;
       }

	if (END_OF_FUNCLIST == action)
	{
		ShowUsage ();
		return 0;
	}

	switch ( action )
	{
		case ENABLE_FAN_CONTROL:
			Verbose   ("Inside Enable Fan Control\n");
			Value = enable_fan_control ( dev_id, fannum );
			if  ( -1 == Value )
			{
				printf ( "Enable Fan Control Failed \n"); 
				return -1;
			}	
			printf ( "Fan %d Control Enabled\n",fannum);
			break;
		case GET_FAN_CONTROL_STATUS:
			Verbose   ("Inside Get Fan Control status\n");
			Value = get_fan_control_status( dev_id, fannum );
			if  ( -1 == Value )
			{
				printf ( "Get Fan Control Status Failed \n"); 
				return -1;
			}
			printf ( "Fan %d Control status is %d\n", fannum, Value);
			break;
		case ENABLE_ALL_FANS_CONTROL:
			Verbose   ("Inside Enable All Fans Control\n");
			Value = enable_all_fans_control ( dev_id );
			if  ( -1 == Value )
			{
				printf ( "Enable All Fans Control Failed \n"); 
				return -1;
			}	
			printf ( "All the Fans Control Enabled\n");
			break;
		case ENABLE_FAN_STATUS_READ:
			Verbose   ("Inside Enable Fan Status Read\n");
			Value = enable_fan_status_read ( dev_id, fannum );
			if  ( -1 == Value )
			{
				printf ( "Enable Fan Status Read Failed \n"); 
				return -1;
			}	
			printf ( "Fan Status Read Enabled for %d\n",fannum);
			break;
		case GET_FAN_STATUS_READ:
			Verbose   ("Inside Get Fan status read\n");
			Value = get_tach_status( dev_id, fannum );
			if  ( -1 == Value )
			{
				printf ( "Get Fan status read Failed \n"); 
				return -1;
			}   
			printf ( "Fan %d read status is %d\n", fannum, Value);
			break;
		case ENABLE_ALL_FANS_STATUS_READ:
			Verbose   ("Inside Enable All Fans Status Read\n");
			Value = enable_all_fans_status_read ( dev_id );
			if  ( -1 == Value )
			{
				printf ( "Enable All Fans Status Read Failed \n"); 
				return -1;
			}	
			printf ( "All Fans Status Read Enabled\n");
			break;
		case SET_FAN_SPEED:
			Verbose   ("Inside Set Fan Speed \n");
			Value = set_fan_speed (dev_id, fannum, rpmvalue);
			if  ( -1 == Value )
			{
				printf ( "Set Fan Speed Failed \n"); 
				return -1;
			}
			printf ( "Fan Speed set Successfully\n");
			break;	
		case GET_FAN_SPEED:
			Verbose   ("Inside Get Fan Speed \n");
			Value = get_fan_speed (dev_id, fannum, &rpmvalue);
			if ( -1 == Value)
			{
				printf ( "Get Fan Speed Failed \n"); 
				return -1;
			}	
			printf("Fan %d speed is %d \n", fannum, rpmvalue);
			break;
		case DISABLE_FAN_CONTROL:
			Verbose   ("Inside Disable Fan Control\n");
			Value = disable_fan_control ( dev_id, fannum );
			if  ( -1 == Value )
			{
				printf ( "Disable Fan Control Failed \n"); 
				return -1;
			}	
			printf ("Fan %d Control Disabled\n", fannum);
			break;
		case DISABLE_ALL_FANS_CONTROL:
			Verbose   ("Inside Disable All Fans Control\n");
			Value = disable_all_fans_control (dev_id);
			if  ( -1 == Value )
			{
				printf ("Disable All Fans Control Failed \n"); 
				return -1;
			}	
			printf ( "All the Fans Control Disabled\n");
			break;
		case DISABLE_FAN_STATUS_READ:
			Verbose   ("Inside Disable Fan Status Read\n");
			Value = disable_fan_status_read (dev_id, fannum);
			if  ( -1 == Value )
			{
				printf ( "Disable Fan Status Read Failed \n");
				return -1;
			}	
			printf ( "Fan Status Read Disabled for %d\n",fannum);
			break;
		case DISABLE_ALL_FANS_STATUS_READ:
			Verbose   ("Inside Disable All Fans Status Read\n");
			Value = disable_all_fans_status_read (dev_id);
			if  ( -1 == Value )
			{
				printf ( "Disable All Fans Status Read Failed \n");
				return -1;
			}	
			printf ( "Fan Status Read Disabled for all\n");
			break;
		case CONF_FAN_MAP_TABLE:
			Verbose    ("Inside Configure Fan Map Table\n");
			Value = configure_fan_map_table (dev_id, (void*)p_fanmap_data, num_fans);
			if  ( -1 == Value )
			{
				printf ( "Configure of Fan Map Table Failed\n" );
				return -1;
			}
			printf ( "Fan Map Table configured\n");
			break;
		case CONF_FAN_PROPERTY_TABLE:
			Verbose    ("Inside Configure Fan Map Property Table\n");
			Value = configure_fan_property_table (dev_id, (void*)p_fanproperty_data, num_fans);
			if  ( -1 == Value )
			{
				printf ( "Configure of Fan Property Table Failed\n" );
				return -1;
			}
			printf ( "Fan Property Table configured\n");
			break;
		case SHOW_FAN_MAP_TABLE:
			Verbose    ("Inside Show Fan Map Table\n");
			Value = show_fan_map_table (dev_id);
			if  ( -1 == Value )
			{
				printf ( "Could not display the Fan Map Table\n" );
				return -1;
			}
			printf ( "Fan Map Table displayed\n");
			break;
		case SHOW_FAN_PROPERTY_TABLE:
			Verbose    ("Inside Show Fan Property Table\n");
			Value = show_fan_property_table (dev_id);
			if  ( -1 == Value )
			{
				printf ( "Could not display Fan Properties Table\n" );
				return -1;
			}
			printf ( "Fan Property Table displayed\n");
			break;
		case SET_PWM_DUTYCYCLE:
			Verbose   ("Inside Set PWM Dutycycle \n");
			Value = set_pwm_dutycycle (dev_id, fannum, rpmvalue);
			if  ( -1 == Value )
			{
				printf ( "Set PWM Dutycycle Failed \n"); 
				return -1;
			}
			printf ( "Fan PWM set dutycycle Successfully\n");
			break;
		case SET_PWM_DUTYCYCLE_VALUE:
			Verbose   ("Inside Set PWM Dutycycle Value\n");
			Value = set_pwm_dutycycle_value (dev_id, fannum, rpmvalue);
			if  ( -1 == Value )
			{
				printf ( "Set PWM Dutycycle Value Failed \n"); 
				return -1;
			}
			printf ( "Fan PWM set dutycycle value Successfully\n");
			break;
		case GET_PWM_DUTYCYCLE:
			Verbose   ("Inside Get PWM Dutycycle \n");
			Value = get_pwm_dutycycle (dev_id, fannum, &dutycycle);
			if  ( -1 == Value )
			{
				printf ( "Set PWM Dutycycle Failed \n"); 
				return -1;
			}
			printf ( "PWM %d Dutycycle is %d\n",fannum, dutycycle);
			break;
		case SET_TACH_PROPERTY:
			Verbose   ("Inside Set Tach Property \n");
			Value = set_tach_property(dev_id, fannum, property_id, property_value);
			if  ( -1 == Value )
			{
				printf ( "Set Tach property Failed \n"); 
				return -1;
			}
			printf ( "Set Tach Property Successfully\n");
			break;
		case GET_TACH_PROPERTY:
			Verbose   ("Inside Get Tach Property \n");
			Value = get_tach_property(dev_id, fannum, property_id, &property_value);
			if  ( -1 == Value )
			{
				printf ( "Get Tach property Failed \n"); 
				return -1;
			}
			printf ( "Tach Property Value : %x\n", property_value);
			break;
		case SET_PWM_PROPERTY:
			Verbose   ("Inside Set PWM Property \n");
			Value = set_pwm_property(dev_id, fannum, property_id, property_value);
			if  ( -1 == Value )
			{
				printf ( "Set PWM property Failed \n"); 
				return -1;
			}
			printf ( "Set PWM Property Successfully\n");
			break;
		case GET_PWM_PROPERTY:
			Verbose   ("Inside Get PWM Property \n");
			Value = get_pwm_property(dev_id, fannum, property_id, &property_value);
			if  ( -1 == Value )
			{
				printf ( "Get PWM property Failed \n"); 
				return -1;
			}
			printf ( "PWM Property Value : %x\n", property_value);
			break;
		case CLEAR_TACH_ERROR:
			Verbose   ("Inside Clear Tach Error\n");
			Value = clear_tach_error(dev_id, fannum);
			if  ( -1 == Value )
			{				
				printf ( "Clear Tach Error Failed \n"); 
				return -1;
			}
			printf ( "Tach Error Cleared Succesfully\n");
			break;
		case CLEAR_PWM_ERRORS:
			Verbose   ("Inside Clear PWM Errors\n");
			Value = clear_pwm_errors(dev_id);
			if  ( -1 == Value )
			{				
				printf ( "Clear PWM Errors Failed \n"); 
				return -1;
			}
			printf ( "PWMCR Errors Cleared Succesfully\n");
			break;
		default:
			Verbose  ("Invalid PWMTACH Function Call\n");
			break;
	}
	return 0;
}

